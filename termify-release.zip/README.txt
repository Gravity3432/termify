Welcome to Termify!
===================

TO INSTALL:  double-click  run.bat   (Windows)
             or run  python3 install.py   then  ./run.sh  (Mac/Linux)

It installs everything automatically - nothing to set up by hand.
The full guide is in README.md. The dev/ folder is for builders only.
