@echo off
REM Termify launcher - Windows safe edition
REM If you ever edit/re-save this file, keep Windows CRLF line endings.
cd /d "%~dp0"

REM -- pick a python interpreter
where py >nul 2>nul
if errorlevel 1 goto try_python
set "PY=py"
goto have_py

:try_python
where python >nul 2>nul
if errorlevel 1 goto no_python
set "PY=python"

:have_py
if exist .venv\Scripts\python.exe goto launch

echo.
echo  [termify] first run: creating virtual environment...
%PY% -m venv .venv
if errorlevel 1 goto venv_fail

echo  [termify] installing dependencies - a few minutes on first run...
.venv\Scripts\python.exe -m pip install --upgrade pip
if errorlevel 1 goto pip_fail
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto pip_fail
goto launch

:venv_fail
echo.
echo  [termify] could not create the virtual environment.
echo  Install Python 3.10+ from python.org and try again.
echo.
pause
exit /b 1

:pip_fail
echo.
echo  [termify] dependency install failed.
echo  Check your internet, delete the .venv folder, run again.
echo.
pause
exit /b 1

:launch
.venv\Scripts\python.exe -m termify %*
if errorlevel 1 goto app_fail
exit /b 0

:app_fail
echo.
echo  ---------------------------------------------
echo  [termify] the app stopped with an error.
echo  The actual cause is printed right above.
echo  ---------------------------------------------
echo.
pause
exit /b 1

:no_python
echo.
echo  [termify] Python was not found.
echo  Install Python 3.10+ from https://python.org/downloads
echo  IMPORTANT: tick the Add python.exe to PATH box, then rerun this file.
echo.
pause
exit /b 1
