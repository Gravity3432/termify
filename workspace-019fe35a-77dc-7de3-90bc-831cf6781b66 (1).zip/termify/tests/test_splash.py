"""Boot splash: the JTMB intro - rain, scramble-resolve letters, typewriter
subline, any-key skip.

Run from the project root:  python tests/test_splash.py
"""
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from rich.layout import Layout
from rich.panel import Panel

from termify import ui
from termify.app import App
from termify.demo_engine import DemoEngine


def make_app(theme="aurora") -> App:
    return App(DemoEngine(), {"volume": 60, "theme": theme}, demo=True)


def render_text(app, w, h, t):
    panel = ui.render_splash(app, w, h, t=t)
    assert isinstance(panel, Panel)
    from rich.console import Console
    console = Console(record=True, width=w, height=h)
    console.print(panel)
    return console.export_text()


def test_splash_timeline():
    app = make_app()
    # early: mostly drizzle, letters not born yet on the far right
    early = render_text(app, 110, 34, 0.2)
    assert "J O H N" not in early          # subline not typed yet
    # mid: some letters resolved, subline typing in progress
    mid = render_text(app, 110, 34, 1.6)
    assert "██" in mid or "█" in mid        # letter strokes visible
    # done: full art + full subline + credit
    final = render_text(app, 110, 34, 4.0)
    for marker in ("████████╗", "██████╔╝",
                   ui.SPLASH_SUB, ui.SPLASH_BY):
        assert marker in final, marker
    print("ok  splash timeline: rain → glitch → resolved letters + typed name")


def test_splash_sizes_and_themes():
    for theme in ("aurora", "vampire", "mono", "ocean"):
        app = make_app(theme)
        for w, h in ((110, 34), (72, 20), (150, 45), (95, 22)):
            for t in (0.05, 0.8, 1.4, 2.35, 3.7):
                render_text(app, w, h, t)  # must never raise
    # vampire uses the blood letters
    vapp = make_app("vampire")
    vamp = render_text(vapp, 120, 38, 4.0)
    assert "▓" in vamp or "▄" in vamp
    print("ok  splash renders for every theme at every size")


def test_boot_wiring():
    app = make_app()
    app.snap = app.engine.snapshot()
    assert app.boot_active()
    frame = app.render(110, 34)
    assert isinstance(frame, Panel)       # splash, not the main Layout
    # any key skips
    app.dispatch("x")
    assert not app.boot_active()
    frame = app.render(110, 34)
    assert isinstance(frame, Layout)      # straight into the real UI
    # a mouse click skips it too
    app2 = make_app()
    app2.on_mouse(0, 5, 5, False)
    assert not app2.boot_active()
    # the key that skipped boot doesn't do anything else (swallowed once)
    print("ok  boot: splash shows first, any key/click skips into the app")


def test_splash_cpu_budget():
    # 20 FPS frames must stay cheap enough on modest machines
    app = make_app()
    t0 = time.monotonic()
    for i in range(20):
        ui.render_splash(app, 120, 36, t=0.2 * i)
    per_frame = (time.monotonic() - t0) / 20
    assert per_frame < 0.05, per_frame
    print(f"ok  splash frame budget: {per_frame * 1000:.0f} ms/frame")


if __name__ == "__main__":
    test_splash_timeline()
    test_splash_sizes_and_themes()
    test_boot_wiring()
    test_splash_cpu_budget()
    print("\nALL SPLASH TESTS PASSED")
