"""Queue view: the dedicated up-next screen (nav 7 / 'u'), jump-to-track,
and kicking songs out of the line.

Run from the project root:  python tests/test_queue_view.py
"""
import time
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from rich.layout import Layout

from termify.app import App, VIEW_ORDER
from termify.demo_engine import DemoEngine, TRACKS
from termify.stream_engine import StreamEngine
from termify import ui


def make_app() -> App:
    app = App(DemoEngine(), {"volume": 60, "theme": "aurora"}, demo=True)
    app.snap = app.engine.snapshot()  # give it a "playing" snapshot
    app.boot_skip()                   # these tests drive keys: skip the splash
    return app


def test_nav_digit_and_u():
    assert VIEW_ORDER[-1] == "queue"
    app = make_app()
    for i, view in enumerate(VIEW_ORDER, 1):
        app.dispatch(str(i))
        assert app.view == view, (i, app.view)
    app.view = "home"
    app.dispatch("u")
    assert app.view == "queue"
    # tab also cycles through it
    app.goto("devices")
    app.dispatch("\t")
    assert app.view == "queue"
    # esc takes you home
    app.dispatch("\x1b")
    assert app.view == "home"
    print("ok  queue opens via 7, u, and tab; esc goes back home")


def test_view_count_and_movement():
    app = make_app()
    app.view = "queue"
    n = app.view_count()
    assert n == len(app.snap.queue) and n >= 3
    app.dispatch("j")
    assert app.sel["queue"] == 1
    app.dispatch("G")
    assert app.sel["queue"] == n - 1
    app.dispatch("g")
    assert app.sel["queue"] == 0
    print("ok  queue view counts rows and scrolls/selects like any list")


def test_enter_jumps_to_spot():
    app = make_app()
    app.view = "queue"
    pos0 = app.engine._pos
    app.sel["queue"] = 2
    app.action_enter()
    time.sleep(0.4)  # _call runs in the pool
    assert app.engine._pos == pos0 + 3, (pos0, app.engine._pos)
    print("ok  enter on a queue row jumps straight to that song")


def test_kick_out_of_queue():
    app = make_app()
    app.view = "queue"
    before = list(app.engine._order)
    kicked = app.engine._tracks[before[app.engine._pos + 1]]  # next-up row
    app.sel["queue"] = 0
    app.dispatch("d")
    time.sleep(0.4)
    assert len(app.engine._order) == len(before) - 1
    remaining = app.engine._order[app.engine._pos + 1:]
    assert before[app.engine._pos + 1] not in remaining or len(set(remaining)) < len(remaining)
    # fresh snapshot no longer shows the kicked track
    names = [t.name for t in app.engine.snapshot().queue]
    assert kicked.name not in names
    print("ok  d kicks the highlighted song out of the queue")


def test_remote_mode_explains_it_cant_edit():
    class Remoteish(DemoEngine):
        mode = "remote"
        queue_remove = None  # spotify's web api has no remove-from-queue

    app = App(Remoteish(), {"volume": 60, "theme": "aurora"}, demo=True)
    app.snap = app.engine.snapshot()
    app.boot_skip()
    app.view = "queue"
    app.sel["queue"] = 0
    app.dispatch("d")
    assert "can't edit the queue" in app.current_toast()
    print("ok  remote mode politely explains the API limit")


class _FakeCore:
    """CoreSession stand-in: pretend every fetch would fail (no audio in tests)."""
    ready = True

    def fetch_ogg(self, uri, quality):
        raise RuntimeError("no audio in tests")


def test_stream_engine_full_depth_queue():
    eng = StreamEngine(None, {"volume": 60}, _FakeCore())
    big = TRACKS * 8  # 128 tracks through the same demo songs
    eng.play_tracks(big, 0, "marathon")
    time.sleep(0.2)
    snap = eng.snapshot()
    assert len(snap.queue) == 100, len(snap.queue)  # not the old 8!
    names0 = [t.name for t in snap.queue]
    # kick the second upcoming track out
    assert eng.queue_remove(1) is True
    assert len(eng._order) == 127  # one fewer in the play order
    snap2 = eng.snapshot()
    names1 = [t.name for t in snap2.queue]
    assert names1[1] == names0[2]  # everything shifted up
    assert len(snap2.queue) == 100  # the cap refills from deeper in the list
    # on a short list the visible count actually shrinks
    eng.play_tracks(TRACKS[:5], 0, "short set")
    time.sleep(0.2)
    assert len(eng.snapshot().queue) == 4
    assert eng.queue_remove(0) is True
    assert len(eng.snapshot().queue) == 3
    # removal of an absurd index is a clean no-op
    assert eng.queue_remove(10_000) is False
    print("ok  stream engine exposes 100 up-next tracks + queue_remove works")


def test_render_queue_view():
    app = make_app()
    app.view = "queue"
    root = ui.build(app, 120, 34)
    assert isinstance(root, Layout)
    ztypes = {z["type"] for z in app.zones}
    assert "queue" in ztypes and "nav" in ztypes
    # smaller terminal + empty queue shouldn't explode either
    app.snap.queue = []
    app.view = "queue"
    ui.build(app, 100, 24)
    app.clamp_sel("queue")
    assert app.sel["queue"] == 0
    # nothing playing at all
    app.snap.track = None
    ui.build(app, 110, 28)
    print("ok  queue view renders big, small, empty, and idle states")


if __name__ == "__main__":
    test_nav_digit_and_u()
    test_view_count_and_movement()
    test_enter_jumps_to_spot()
    test_kick_out_of_queue()
    test_remote_mode_explains_it_cant_edit()
    test_stream_engine_full_depth_queue()
    test_render_queue_view()
    print("\nALL QUEUE-VIEW TESTS PASSED")
