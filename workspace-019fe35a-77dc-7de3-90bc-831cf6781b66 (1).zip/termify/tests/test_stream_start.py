"""Speed tests: streaming decode starts the music BEFORE the song has fully
downloaded, the next track is prefetched so skipping is instant, the live
stream's seek-through copy works, the full-download fallback saves a bad
stream - and the vampire theme wears its bloody banner.

Run from the project root:  python tests/test_stream_start.py
"""
import io
import math
import threading
import time
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import av
import numpy as np

from termify import config, ui
from termify import stream_engine as se
from termify.audio_sink import BaseSink
from termify.models import Track
from termify.app import App
from termify.demo_engine import DemoEngine, TRACKS


# ------------------------------------------------------------ shared fakes
def make_ogg(seconds: float = 3.0, rate: int = 48000) -> bytes:
    """Bake a real OGG song (a 220 Hz sine) fresh for the test run."""
    buf = io.BytesIO()
    c = av.open(buf, "w", format="ogg")
    s = c.add_stream("libopus", rate=rate)
    s.layout = "stereo"
    n = int(rate * seconds)
    steps = np.arange(n) / rate
    samples = (12000 * np.sin(2 * math.pi * 220 * steps)).astype(np.int16)
    stereo = np.stack([samples, samples], axis=1)
    for off in range(0, n, 960):  # 20 ms frames, the opus way
        block = stereo[off:off + 960].flatten().reshape(1, -1)
        f = av.AudioFrame.from_ndarray(block, format="s16", layout="stereo")
        f.sample_rate = rate
        f.pts = off
        for pkt in s.encode(f):
            c.mux(pkt)
    for pkt in s.encode():
        c.mux(pkt)
    c.close()
    return buf.getvalue()


class SlowStream(io.BytesIO):
    """Pretend the network is a sloth: drip-feed chunks of the OGG."""

    def __init__(self, data: bytes, chunk: int = 3_000, delay: float = 0.03):
        super().__init__(data)
        self.chunk = chunk
        self.delay = delay
        self.reads = 0

    def read(self, n: int = -1) -> bytes:
        if n is None or n < 0 or n > self.chunk:
            n = self.chunk
        time.sleep(self.delay)
        self.reads += 1
        return super().read(n)

    def full_download_seconds(self, size: int) -> float:
        return math.ceil(size / self.chunk) * self.delay


class FakeSink(BaseSink):
    """Eats PCM at the correct real-time rate, zero audio hardware needed."""

    def __init__(self, ring):
        super().__init__(ring)
        self._run = False
        self._thread = None

    def start(self) -> None:
        if self._run:
            return
        self._run = True

        def drain():
            while self._run:
                if not self.paused:
                    data = self.ring.take(4096)
                    if data:
                        with self._played_lock:
                            self._played_bytes += len(data)
                        time.sleep(len(data) / 176_400)  # real-time pacing
                        continue
                time.sleep(0.005)

        self._thread = threading.Thread(target=drain, daemon=True, name="fake-sink")
        self._thread.start()

    def close(self) -> None:
        self._run = False


_FAKE_PICK = lambda ring, pref="auto": FakeSink(ring)  # noqa: E731


def wait_state(player, states, timeout: float = 8.0) -> str:
    t0 = time.monotonic()
    while time.monotonic() - t0 < timeout:
        if player.state in states:
            return player.state
        time.sleep(0.02)
    return player.state


def make_track(seconds: int) -> Track:
    return Track(id="t", uri="spotify:track:t", name="Sine",
                 artists="Test", album="Fixtures", duration_ms=seconds * 1000)


def test_stream_starts_before_full_download():
    ogg = make_ogg(4.0)                      # ~53 KB, slow net: ~0.55 s total
    slow = SlowStream(ogg)
    full_time = slow.full_download_seconds(len(ogg))
    old = se.pick_sink
    se.pick_sink = _FAKE_PICK
    try:
        p = se.PCMPlayer(prebuffer_ms=100)
        t0 = time.monotonic()
        p.load_and_play(make_track(4), fetcher=lambda: (_ for _ in ()).throw(
            RuntimeError("must never whole-download")), stream_opener=lambda: slow)
        assert wait_state(p, ("playing", "error"), 8) == "playing", p.error
        to_playing = time.monotonic() - t0
        assert to_playing < full_time * 0.7, (
            f"playing took {to_playing:.2f}s vs full download {full_time:.2f}s")
        # and it CANNOT have read the whole file yet
        assert slow.reads < math.ceil(len(ogg) / slow.chunk), slow.reads
        # once fully decoded, the tee'd copy exists for seeking
        wait_state(p, ("idle", "playing"), 8)
        t_end = time.monotonic() + 6
        while not p._decode_done and time.monotonic() < t_end:
            time.sleep(0.05)
        assert p._decode_done and p._ogg is not None
        p.seek(0)  # seek through the accumulated copy - must not explode
        assert p.state in ("buffering", "playing")
        p.shutdown()
    finally:
        se.pick_sink = old
    print("ok  streaming: music starts long before the file is done, "
          "then seeks via the tee'd copy")


def test_bad_stream_falls_back_to_full_download():
    ogg = make_ogg(2.0)
    calls = {"fetch": 0}

    def fetch():
        calls["fetch"] += 1
        return ogg

    old = se.pick_sink
    se.pick_sink = _FAKE_PICK
    try:
        p = se.PCMPlayer(prebuffer_ms=100)
        p.load_and_play(
            make_track(2),
            fetcher=fetch,
            stream_opener=lambda: io.BytesIO(b"definitely not an ogg"),
        )
        assert wait_state(p, ("playing", "error"), 8) == "playing", p.error
        assert calls["fetch"] == 1, calls
        assert p._ogg == ogg  # full download won, seek-ready
        p.shutdown()
    finally:
        se.pick_sink = old
    print("ok  fallback: a dead stream quietly becomes a classic download")


class FakeCore:
    ready = True

    def __init__(self, ogg: bytes):
        self.ogg = ogg
        self.fetches = []
        self.streams = []

    def fetch_ogg(self, uri, quality):
        self.fetches.append(uri)
        time.sleep(0.05)
        return self.ogg

    def open_ogg_stream(self, uri, quality):
        self.streams.append(uri)
        return io.BytesIO(self.ogg)


def test_prefetch_makes_next_instant():
    ogg = make_ogg(2.0)
    core = FakeCore(ogg)
    old = se.pick_sink
    se.pick_sink = _FAKE_PICK
    try:
        eng = se.StreamEngine(None, {"volume": 60, "prebuffer_ms": 100}, core)
        a, b = TRACKS[0], TRACKS[1]
        eng.play_tracks([a, b], 0, "fixtures")
        assert wait_state(eng.player, ("playing", "error"), 8) == "playing", \
            eng.player.error
        time.sleep(0.8)  # prefetch thread has time to warm track B
        with eng._prebuf_lock:
            assert b.uri in eng._prebuf
        eng.next()
        assert wait_state(eng.player, ("playing", "error"), 8) == "playing", \
            eng.player.error
        # Exactly one whole-file download happened: the prefetch of B.
        # A came off the live stream, and B never hit the network again
        # when we skipped to it.
        assert core.fetches == [b.uri], core.fetches
        assert core.streams == [a.uri], core.streams
        with eng._prebuf_lock:
            assert b.uri not in eng._prebuf  # popped = decoded instantly
        eng.shutdown()
    finally:
        se.pick_sink = old
    print("ok  prefetch: next song is warm in the sneakernet cache, "
          "zero network on skip")


def test_vampire_theme_and_banner():
    assert "vampire" in ui.THEMES
    assert "vampire" in config.ORDERED_THEMES
    blood = ui.banner_for("vampire")
    assert len(blood) == 10 and any("▓" in l for l in blood)
    # base for every other theme stays the classic block font
    assert ui.banner_for("aurora") == ui.BIG_LOGO
    for theme in ("vampire", "aurora", "mono"):
        app = App(DemoEngine(), {"volume": 60, "theme": theme}, demo=True)
        app.snap = app.engine.snapshot()
        for w, h in ((140, 36), (100, 28), (118, 33)):
            ui.build(app, w, h)  # must not raise at any size
    # vampire hue actually lives in the red/violet night zone
    cols = {ui.theme_color("vampire", t0) for t0 in (0.1, 3.0, 7.5)}
    assert all(c.startswith("#") for c in cols)
    print("ok  vampire: theme, bloody banner, renders at every window size")


if __name__ == "__main__":
    test_stream_starts_before_full_download()
    test_bad_stream_falls_back_to_full_download()
    test_prefetch_makes_next_instant()
    test_vampire_theme_and_banner()
    print("\nALL STREAM-START TESTS PASSED")
