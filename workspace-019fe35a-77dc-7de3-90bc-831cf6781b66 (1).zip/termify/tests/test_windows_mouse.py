"""Windows mouse: raw console INPUT_RECORD translation -> real clicks.

The pure translator runs on any OS, so Linux validates the exact logic that
runs on the user's Windows 11 machine. Also drives the app's on_mouse to
prove a record-press actually activates UI elements.

Run from the project root:  python tests/test_windows_mouse.py
"""
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from termify import input_layer as il
from termify.app import App
from termify.demo_engine import DemoEngine


def mouse_ev(**kw):
    base = {"type": "mouse", "x": 10, "y": 5, "buttons": 0, "flags": 0,
            "delta": 0}
    base.update(kw)
    return base


def test_button_press_release():
    prev = 0
    ev, prev = il.translate_console_record(mouse_ev(flags=0, buttons=1), prev)
    assert ev == ("mouse", 0, 10, 5, True), ev      # left down
    ev, prev = il.translate_console_record(mouse_ev(flags=0, buttons=0), prev)
    assert ev == ("mouse", 0, 10, 5, False), ev     # left up
    ev, prev = il.translate_console_record(mouse_ev(flags=0, buttons=2), 0)
    assert ev == ("mouse", 2, 10, 5, True), ev      # right down
    ev, prev = il.translate_console_record(mouse_ev(flags=0, buttons=4), 0)
    assert ev == ("mouse", 1, 10, 5, True), ev      # middle down
    # no change -> no event
    ev, prev = il.translate_console_record(mouse_ev(flags=0, buttons=0), 0)
    assert ev is None
    print("ok  records: press / release edges on all three buttons")


def test_motion_is_not_a_click():
    prev = 0
    # hovering with NO buttons held => motion, pressed=False (or a hung app
    # would read every hover as a left click!)
    ev, prev = il.translate_console_record(mouse_ev(flags=1, buttons=0), prev)
    assert ev == ("mouse", 32, 10, 5, False), ev
    # drag with left held => motion, pressed=True
    ev, prev = il.translate_console_record(mouse_ev(flags=1, buttons=1), prev)
    assert ev == ("mouse", 32, 10, 5, True), ev
    # double-tap record => plain press
    ev, prev = il.translate_console_record(mouse_ev(flags=2, buttons=1), prev)
    assert ev == ("mouse", 0, 10, 5, True), ev
    print("ok  records: hover never becomes a click; drag keeps pressed state")


def test_wheel_and_keys():
    ev, _ = il.translate_console_record(mouse_ev(flags=4, delta=120), 0)
    assert ev == ("mouse", 64, 10, 5, False), ev      # wheel up
    ev, _ = il.translate_console_record(mouse_ev(flags=4, delta=-120), 0)
    assert ev == ("mouse", 65, 10, 5, False), ev      # wheel down
    key = lambda **k: {"type": "key", "down": True, "vk": 0, "char": "", **k}
    assert il.translate_console_record(key(vk=0x26), 0)[0] == ("key", il.K_UP)
    assert il.translate_console_record(key(vk=0x0D, char="\r"), 0)[0] == ("key", "\r")
    assert il.translate_console_record(key(vk=ord("U"), char="u"), 0)[0] == ("key", "u")
    assert il.translate_console_record(key(vk=0x43, char="\x03"), 0)[0] == ("key", "\x03")
    # key-up records are ignored
    assert il.translate_console_record(key(down=False, vk=0x26), 0)[0] is None
    print("ok  records: wheel directions + key vk/char mapping, key-up ignored")


def make_app() -> App:
    app = App(DemoEngine(), {"volume": 60, "theme": "aurora"}, demo=True)
    app.snap = app.engine.snapshot()
    app.boot_skip()
    return app


def feed(app, ev_dict, prev):
    ev, prev = il.translate_console_record(ev_dict, prev)
    if ev and ev[0] == "mouse":
        app.on_mouse(ev[1], ev[2], ev[3], ev[4])
    return prev


def test_records_drive_the_real_ui():
    app = make_app()
    W, H = 130, 38
    app.render(W, H)
    prev = 0
    # click the "queue" nav item like a Windows record would
    z = next(z for z in app.zones if z["type"] == "nav" and z["view"] == "queue")
    prev = feed(app, mouse_ev(x=z["x"], y=z["y"], flags=0, buttons=1), prev)
    prev = feed(app, mouse_ev(x=z["x"], y=z["y"], flags=0, buttons=0), prev)
    assert app.view == "queue", app.view
    # hover-dragging across rows with nothing held = no accidental triggers
    app.render(W, H)
    qz = [z for z in app.zones if z["type"] == "queue"]
    pos_before = app.engine._pos
    for row in qz:
        prev = feed(app, mouse_ev(x=row["x"], y=row["y"], flags=1, buttons=0), prev)
    assert app.engine._pos == pos_before
    # press a queue row for real -> jumps
    feed(app, mouse_ev(x=qz[1]["x"], y=qz[1]["y"], flags=0, buttons=1), prev)
    time.sleep(0.4)
    assert app.engine._pos == pos_before + 2  # row index 1 -> pos+1+1
    print("ok  full journey: records -> nav click, safe hover, queue jump")


if __name__ == "__main__":
    test_button_press_release()
    test_motion_is_not_a_click()
    test_wheel_and_keys()
    test_records_drive_the_real_ui()
    print("\nALL WINDOWS MOUSE TESTS PASSED")
