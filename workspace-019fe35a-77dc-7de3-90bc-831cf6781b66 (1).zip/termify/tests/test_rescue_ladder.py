"""Self-healing playback: the 'some songs just dont play' battery.

Covers the failure shapes behind the classic
  'decoder: Invalid data found when processing input' toast:
  * a stream whose FIRST bytes are garbage (Spotify hands a bad key/CDN hop)
  * poisoned prefetched bytes in the sneakernet cache
  * a track that simply refuses to play -> skip it, don't sit in silence
  * everything failing -> circuit breaker instead of an infinite skip loop

Run from the project root:  python tests/test_rescue_ladder.py
"""
import io
import sys
import time
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from termify import auth
from termify import stream_engine as se
from termify.models import Track

from test_stream_start import (FakeSink, make_ogg, make_track,  # noqa: E402
                               wait_state)


# ------------------------------------------------------------- fake cores
class CoreError(Exception):
    pass


class FlakyStreamCore:
    """Live streams are fine; whole-file fetch is healthy too."""

    ready = True

    def __init__(self, ogg: bytes):
        self.ogg = ogg
        self.fetches = []
        self.streams = []

    def fetch_ogg(self, uri, quality):
        self.fetches.append(uri)
        time.sleep(0.02)
        return self.ogg

    def open_ogg_stream(self, uri, quality):
        self.streams.append(uri)
        return io.BytesIO(self.ogg)


class PoisonOnceCore(FlakyStreamCore):
    """The FIRST whole-file fetch for the poison uri comes back as junk
    (the mid-air download glitch). Everything else is healthy."""

    def __init__(self, ogg: bytes, poison_uri: str):
        super().__init__(ogg)
        self.poison_uri = poison_uri
        self._poisoned = False

    def fetch_ogg(self, uri, quality):
        self.fetches.append(uri)
        time.sleep(0.02)
        if uri == self.poison_uri and not self._poisoned:
            self._poisoned = True
            return b"PK\x03\x04 not really an ogg at all"
        return self.ogg


class DeadCore(FlakyStreamCore):
    """Spotify says no at every turn."""

    def fetch_ogg(self, uri, quality):
        self.fetches.append(uri)
        raise CoreError("could not load track: stream offline")

    def open_ogg_stream(self, uri, quality):
        self.streams.append(uri)
        raise CoreError("could not open stream: stream offline")


class OneDeadCore(FlakyStreamCore):
    """Exactly one track (by uri) is cursed; everything else plays."""

    def __init__(self, ogg: bytes, dead_uri: str):
        super().__init__(ogg)
        self.dead_uri = dead_uri

    def fetch_ogg(self, uri, quality):
        if uri == self.dead_uri:
            raise CoreError("could not load track: gone")
        return super().fetch_ogg(uri, quality)

    def open_ogg_stream(self, uri, quality):
        if uri == self.dead_uri:
            raise CoreError("could not open stream: gone")
        return super().open_ogg_stream(uri, quality)


def _engine(core, toasts):
    eng = se.StreamEngine(None, {"volume": 60, "prebuffer_ms": 100}, core)
    eng._toast_cb = toasts.append
    return eng


def _wait_for(pred, timeout=20.0):
    t0 = time.monotonic()
    while time.monotonic() - t0 < timeout:
        if pred():
            return True
        time.sleep(0.03)
    return False


# --------------------------------------------------------------- the tests
def test_chain_stream_reads_across_head():
    ogg = make_ogg(1.5)
    head, rest = ogg[:4], io.BytesIO(ogg[4:])
    ch = auth._ChainStream(head, rest)
    assert ch.read(0) == b""            # guard: never "give me everything"
    buf = bytearray(ch.read(2))          # entirely inside the head
    assert bytes(buf) == ogg[:2]
    while True:                          # tiny reads walk the whole chain
        part = ch.read(37)
        if not part:
            break
        buf += part
    assert bytes(buf) == ogg, "chained bytes must equal the original file"
    ch.close()
    assert ch.read(4) == b""

    # read(-1) drains head + rest
    ch2 = auth._ChainStream(ogg[:4], io.BytesIO(ogg[4:]))
    assert ch2.read(-1) == ogg

    # and most importantly: an OGG decoder happily eats the chained stream
    chunks = list(se.decode_chunks(auth._ChainStream(ogg[:4],
                                                     io.BytesIO(ogg[4:]))))
    assert chunks and sum(len(c) for c in chunks) > 10_000
    print("ok  chain stream: verified head + live rest read as one file")


def test_open_ogg_stream_sniffs_and_retries():
    ogg = make_ogg(1.0)
    core = auth.CoreSession({})
    loads = []

    def fake_loaded(data):
        return SimpleNamespace(
            input_stream=SimpleNamespace(stream=lambda: io.BytesIO(data)))

    # first answer: junk from byte zero; second: the real song
    answers = [b"\x00\x11\x22\x33bogus", ogg]

    def fake_load(uri, quality="high"):
        loads.append(uri)
        return fake_loaded(answers.pop(0))

    core._load_stream = fake_load
    stream = core.open_ogg_stream("spotify:track:x")
    assert len(loads) == 2, f"should reload a corrupt stream: {loads}"
    got = stream.read(8)
    assert got == ogg[:8], got[:8]
    rest = stream.read()
    assert got + rest == ogg

    # junk forever -> clean CoreError after bounded attempts
    core2 = auth.CoreSession({})
    calls = {"n": 0}

    def always_bad(uri, quality="high"):
        calls["n"] += 1
        return fake_loaded(b"garbagegarbage")

    core2._load_stream = always_bad
    try:
        core2.open_ogg_stream("spotify:track:x")
        raise AssertionError("expected CoreError")
    except auth.CoreError:
        pass
    assert calls["n"] == 2, calls
    print("ok  sniff: corrupt first bytes mean an instant fresh stream, "
          "never a decoder funeral")


def test_garbage_at_start_self_heals():
    """Byte-zero junk: fresh stream (also junk) -> healthy full download.
    The listener hears music, never the word 'decoder'."""
    ogg = make_ogg(2.0)
    junk = io.BytesIO(b"JUNKJUNKJUNK not ogg")
    opens = {"n": 0}
    fetches = {"n": 0}
    events = []

    def opener():
        opens["n"] += 1
        return io.BytesIO(junk.getvalue())

    def fetch():
        fetches["n"] += 1
        return ogg

    old = se.pick_sink
    se.pick_sink = lambda ring, pref="auto": FakeSink(ring)
    try:
        p = se.PCMPlayer(prebuffer_ms=100,
                         on_event=lambda e: events.append(e))
        p.load_and_play(make_track(2), fetcher=fetch, stream_opener=opener,
                        fresh_fetcher=fetch)
        assert wait_state(p, ("playing", "error"), 10) == "playing", p.error
        assert "error" not in events, events
        assert opens["n"] == 2 and fetches["n"] == 1, (opens, fetches)
        assert p._rescues == 2 and p._fell_back
        assert "playing" in events
        p.shutdown()
    finally:
        se.pick_sink = old
    print("ok  self-heal: junk at the start -> fresh stream -> full fetch, "
          "music plays with zero error toasts")


def test_poisoned_prefetch_never_kills_track():
    """The sneakernet cache held poisoned bytes for song B (this is exactly
    the 'some songs just dont play' bug). B must still play."""
    a = Track(id="a", uri="spotify:track:a", name="Alright", artists="T",
              album="T", duration_ms=2000)
    b = Track(id="b", uri="spotify:track:b", name="Brokenwing", artists="T",
              album="T", duration_ms=2000)
    ogg = make_ogg(2.0)
    core = PoisonOnceCore(ogg, b.uri)
    toasts = []
    old = se.pick_sink
    se.pick_sink = lambda ring, pref="auto": FakeSink(ring)
    try:
        eng = _engine(core, toasts)
        eng.play_tracks([a, b], 0, "fixtures")
        assert wait_state(eng.player, ("playing", "error"), 10) == "playing", \
            eng.player.error
        # prefetch of B fetched ONCE, got poison, and must NOT have cached it
        assert _wait_for(lambda: core.fetches.count(b.uri) >= 1, 5)
        with eng._prebuf_lock:
            assert b.uri not in eng._prebuf, "poison must never be cached"
        # even if poison somehow lands in the cache, _get_ogg must refuse it
        with eng._prebuf_lock:
            eng._prebuf[b.uri] = b"PK\x03\x04 definitely not an ogg"
        eng.next()
        assert wait_state(eng.player, ("playing", "error"), 10) == "playing", \
            eng.player.error
        assert eng.player.track.uri == b.uri
        assert not any("decoder" in t for t in toasts), toasts
        eng.shutdown()
    finally:
        se.pick_sink = old
    print("ok  poisoned prefetch: cache can't kill a song anymore")


def test_dead_track_auto_skips_then_breaks_circuit():
    """Every track dead: skip, skip... then stop and say so (no infinite
    skip loop chewing the whole library)."""
    tracks = [Track(id=c, uri=f"spotify:track:{c}", name=f"Song {c}",
                    artists="T", album="T", duration_ms=2000)
              for c in "abcd"]
    core = DeadCore(b"")
    toasts = []
    old = se.pick_sink
    se.pick_sink = lambda ring, pref="auto": FakeSink(ring)
    try:
        eng = _engine(core, toasts)
        eng.play_tracks(tracks, 0, "fixtures")
        assert _wait_for(lambda: any("keeps failing" in t for t in toasts),
                         25), toasts
        skips = [t for t in toasts if "skipping it" in t]
        assert len(skips) == 2, toasts  # a->b->c, then the breaker fires
        assert eng._error_streak >= 3
        eng.shutdown()
    finally:
        se.pick_sink = old
    print("ok  auto-skip: dead songs get skipped; a dead CONNECTION "
          "stops the music politely")


def test_one_dead_track_skips_and_recovers():
    """One cursed song among friends: it gets skipped, the next one plays,
    the failure streak resets."""
    a = Track(id="a", uri="spotify:track:a", name="Cursed", artists="T",
              album="T", duration_ms=2000)
    b = Track(id="b", uri="spotify:track:b", name="Blessed", artists="T",
              album="T", duration_ms=2000)
    ogg = make_ogg(1.5)
    core = OneDeadCore(ogg, a.uri)
    toasts = []
    old = se.pick_sink
    se.pick_sink = lambda ring, pref="auto": FakeSink(ring)
    try:
        eng = _engine(core, toasts)
        eng.play_tracks([a, b], 0, "fixtures")
        assert _wait_for(
            lambda: eng.player.state == "playing"
            and getattr(eng.player.track, "uri", None) == b.uri, 20), \
            (eng.player.state, eng.player.error, toasts)
        assert any("skipping it" in t for t in toasts), toasts
        assert eng._error_streak == 0, eng._error_streak
        eng.shutdown()
    finally:
        se.pick_sink = old
    print("ok  recovery: the cursed song is skipped, the party continues")


if __name__ == "__main__":
    test_chain_stream_reads_across_head()
    test_open_ogg_stream_sniffs_and_retries()
    test_garbage_at_start_self_heals()
    test_poisoned_prefetch_never_kills_track()
    test_dead_track_auto_skips_then_breaks_circuit()
    test_one_dead_track_skips_and_recovers()
    print("\nALL RESCUE-LADDER TESTS PASSED")
