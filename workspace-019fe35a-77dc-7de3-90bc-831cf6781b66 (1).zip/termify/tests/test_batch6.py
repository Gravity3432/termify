"""Batch 6: genius lyrics fallback, lyrics under Devices, right-click
add-to-playlist, beefier buttons, and the stream-corruption rescue.

Run from the project root:  python tests/test_batch6.py
"""
import io
import os
import sys
import time
import types
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from rich.console import Console

from termify import lyrics, ui
from termify import stream_engine as se
from termify.app import App
from termify.demo_engine import DemoEngine
from termify.models import Track
from termify.audio_sink import BaseSink

from test_stream_start import FakeSink, make_ogg, wait_state, make_track


def make_app() -> App:
    app = App(DemoEngine(), {"volume": 60, "theme": "aurora"}, demo=True)
    app.snap = app.engine.snapshot()
    app.boot_skip()
    return app


def text_of(panel, w=110, h=24):
    console = Console(record=True, width=w, height=h)
    console.print(panel)
    return console.export_text()


class _Resp:
    def __init__(self, status=200, data=None, text=""):
        self.status_code = status
        self._data = data
        self.text = text

    def json(self):
        return self._data


def fake_requests(routes):
    fake = types.ModuleType("requests")

    def get(url, params=None, headers=None, timeout=None):
        for key, resp in routes.items():
            if key in url:
                return resp
        raise RuntimeError(f"unexpected url: {url}")

    fake.get = get
    return fake


def with_fake_requests(routes, fn):
    orig = sys.modules.get("requests")
    sys.modules["requests"] = fake_requests(routes)
    try:
        return fn()
    finally:
        if orig is not None:
            sys.modules["requests"] = orig
        else:
            sys.modules.pop("requests", None)


GENIUS_PAGE = """
<html><body>
<div data-lyrics-container="true">First line of the song<br/>Second line rides on</div>
<div data-lyrics-container="true">Hook hook hook<br/>Chorus time</div>
</body></html>
"""
GENIUS_SEARCH = {"response": {"sections": [
    {"type": "song",
     "hits": [{"result": {"url": "https://genius.com/Artist-song-lyrics",
                          "lyrics_state": "complete"}}]},
]}}


def test_genius_parse_and_source_flow():
    tr = Track(id="g1", uri="spotify:track:g1", name="Deep Song",
               artists="Night Owls, Moon", album="", duration_ms=200_000)
    lines = with_fake_requests(
        {"api/search": _Resp(200, GENIUS_SEARCH),
         "genius.com/Artist": _Resp(200, text=GENIUS_PAGE)},
        lambda: lyrics._genius_lyrics(tr))
    assert lines == ["First line of the song", "Second line rides on",
                     "Hook hook hook", "Chorus time"], lines
    # full flow: lrclib 404 -> genius wins, source tagged
    lyrics._CACHE.pop("g2", None)
    tr2 = Track(id="g2", uri="spotify:track:g2", name="Deep Song",
                artists="Night Owls", album="", duration_ms=200_000)
    res = with_fake_requests(
        {"lrclib.net": _Resp(404),
         "api/search": _Resp(200, GENIUS_SEARCH),
         "genius.com/Artist": _Resp(200, text=GENIUS_PAGE)},
        lambda: lyrics.fetch_lyrics(tr2))
    assert res["source"] == "genius" and res["plain"] and not res["synced"]
    # when lrclib works, genius stays quiet
    lyrics._CACHE.pop("g3", None)
    tr3 = Track(id="g3", uri="spotify:track:g3", name="Sync Me",
                artists="Night Owls", album="", duration_ms=200_000)
    res2 = with_fake_requests(
        {"lrclib.net": _Resp(200, {"syncedLyrics": "[00:01.00]hi\n[00:03.00]there",
                                   "plainLyrics": ""})},
        lambda: lyrics.fetch_lyrics(tr3))
    assert res2["source"] == "lrclib" and res2["synced"]
    print("ok  genius: page parsed, source flow, lrclib takes priority")


def test_right_click_opens_picker():
    app = make_app()
    rows = app.engine.get_liked()
    app.rows["liked"] = rows
    app.rows_orig["liked"] = list(rows)
    app.view = "liked"
    app.render(110, 30)
    z = next(z for z in app.zones if z["type"] == "select"
             and z["view"] == "liked" and z["index"] == 2)
    app.on_mouse(2, z["x"], z["y"], True)   # RIGHT click
    assert app.picker is not None
    assert app.picker["track"].id == rows[2].id
    app.picker = None
    # right-clicking a queue row works too
    app.view = "home"
    app.render(110, 30)
    qz = next(z for z in app.zones if z["type"] == "queue" and z["index"] == 0)
    app.on_mouse(2, qz["x"], qz["y"], True)
    assert app.picker is not None
    assert app.picker["track"].id == app.snap.queue[0].id
    print("ok  right-click: beloved rows and queue rows open the picker")


def test_lyrics_under_devices():
    app = make_app()
    app.view = "devices"
    app.lyrics_state = {
        "id": app.snap.track.id,
        "synced": [(0, "line zero"), (5000, "line one"), (9000, "line two"),
                   (13000, "line three"), (17000, "line four"), (21000, "five")],
        "plain": [], "source": "lrclib", "loading": False,
    }
    app.snap.position_ms = 9500
    screen = text_of(ui.render_devices(app, 90, 30, 1, 1), 92, 30)
    assert "LYRICS" in screen and "line one" in screen and "line two" in screen
    # genius-sourced plain lyrics show up with attribution
    app.lyrics_state = {"id": "x", "synced": [], "plain": ["jumped off base"],
                        "source": "genius", "loading": False}
    screen = text_of(ui.render_devices(app, 90, 30, 1, 1), 92, 30)
    assert "genius.com" in screen and "jumped off base" in screen
    print("ok  devices view karaoke block incl. genius attribution")


def test_button_sizes():
    app = make_app()
    app.render(120, 36)
    btns = {z["action"]: z for z in app.zones if z["type"] == "btn"}
    assert btns["toggle"]["w"] == 6 and btns["prev"]["w"] == 6
    assert btns["next"]["w"] == 6 and btns["repeat"]["w"] == 8
    assert btns["shuffle"]["w"] == 6
    screen = text_of(ui.render_footer(app, 120, 2, 33), 122, 6)
    assert "[ ❚❚ ]" in screen and "[ ◄◄ ]" in screen and "[ ►► ]" in screen
    print("ok  footer buttons: 30-50% wider with bold bracket frames")


class BombStream:
    """Realistic network villain: valid first N bytes, then the wires snap."""

    def __init__(self, data: bytes, live_bytes: int):
        self._buf = data[:live_bytes]
        self._pos = 0

    def read(self, n: int = -1) -> bytes:
        if self._pos >= len(self._buf):
            raise IOError("decoder: Invalid data found when processing input")
        if n is None or n <= 0:
            n = len(self._buf) - self._pos
        chunk = self._buf[self._pos:self._pos + n]
        self._pos += len(chunk)
        return chunk

    def close(self):
        pass


def test_stream_corruption_rescue():
    """Mid-stream failure: previously 'decoder: Invalid data' and dead;
    now the player quietly refetches + keeps playing from where it was."""
    ogg = make_ogg(6.0, rate=24000)
    events = []
    calls = {"fetches": 0}

    def rescue_fetch():
        calls["fetches"] += 1
        return ogg

    old = se.pick_sink
    se.pick_sink = lambda ring, pref="auto": FakeSink(ring)
    try:
        p = se.PCMPlayer(prebuffer_ms=100,
                         on_event=lambda e: events.append(e))
        p.load_and_play(make_track(6), fetcher=rescue_fetch,
                        stream_opener=lambda: BombStream(ogg, 40 * 1024))
        t0 = time.monotonic()
        while time.monotonic() - t0 < 10:
            if calls["fetches"] == 1 and p.state == "playing":
                break
            time.sleep(0.05)
        assert calls["fetches"] == 1, calls
        assert p.state == "playing", p.error
        assert p._fell_back is True
        assert "error" not in events, events
        p.shutdown()
    finally:
        se.pick_sink = old
    print("ok  stream rescue: mid-stream failure → silent refetch + keep playing")


if __name__ == "__main__":
    test_genius_parse_and_source_flow()
    test_right_click_opens_picker()
    test_lyrics_under_devices()
    test_button_sizes()
    test_stream_corruption_rescue()
    print("\nALL BATCH-6 TESTS PASSED")
