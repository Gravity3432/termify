"""Tests for the Feb-2026 Spotify API migration fixes:
search limit cap (50->10), /me/library consolidation, /me/playlists,
artist top-tracks removal.

Run from the project root:  python tests/test_api_migration.py
"""
import sys
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from termify.catalog import Catalog


def _mk_track(i):
    return {
        "id": f"t{i}", "uri": f"spotify:track:t{i}", "name": f"song {i}",
        "artists": [{"name": "singer"}],
        "album": {"name": "alb", "images": []},
        "duration_ms": 1000, "type": "track",
    }


class FakeSP:
    """Pretends to be spotipy.Spotify under the Feb-2026 rules."""

    def __init__(self):
        self.calls = []

    def search(self, q, limit=None, offset=0, type="track"):
        assert limit is not None and limit <= 10, \
            f"Spotify would reject limit={limit} (post-migration max is 10)"
        self.calls.append({"q": q, "limit": limit, "offset": offset, "type": type})
        out = {}
        if "artist" in type:
            out["artists"] = {"items": [{"id": "a1", "uri": "", "name": "singer",
                                         "images": []}]}
        if "album" in type:
            out["albums"] = {"items": [{"id": "al1", "uri": "", "name": "alb",
                                        "artists": [{"name": "singer"}],
                                        "images": [], "release_date": "2024"}]}
        if "playlist" in type:
            out["playlists"] = {"items": [{
                "id": "p1", "uri": "", "name": "mix",
                "owner": {"display_name": "x"}, "images": [],
                "items": {"total": 3}}]}
        if "track" in type:
            page = [_mk_track(i) for i in range(25)][offset: offset + limit]
            out["tracks"] = {"items": page}
        return out


class _Resp:
    def __init__(self, code, data=None):
        self.status_code = code
        self._data = data

    def json(self):
        return self._data


def test_search_paginates_within_cap():
    cat = Catalog(FakeSP())
    with patch("requests.get", return_value=_Resp(200, [False] * 40)):
        out = cat.search("singer", cap=25)
    assert len(out) == 25
    assert [c["limit"] for c in cat.sp.calls] == [10, 10, 5]
    assert [c["offset"] for c in cat.sp.calls] == [0, 10, 20]
    assert out[0].name == "song 0" and out[-1].name == "song 24"
    print("ok  search: paginates 10/10/5 under the new limit cap")


def test_search_all_sections():
    cat = Catalog(FakeSP())
    with patch("requests.get", return_value=_Resp(200, [False] * 40)):
        res = cat.search_all("singer")
    assert res["artists"] and res["albums"] and res["playlists"]
    assert len(res["tracks"]) == 25
    first = cat.sp.calls[0]
    assert first["limit"] <= 10 and "track" not in first["type"]
    print("ok  search_all: all 4 sections, per-type limit respected")


def test_artist_top_uses_search_not_removed_endpoint():
    cat = Catalog(FakeSP())

    class Artist:
        name = "singer"

    with patch("requests.get", return_value=_Resp(200, [False] * 40)):
        out = cat.artist_top(Artist())
    assert len(out) == 20
    assert FakeSP.search is not None  # spotipy would 404 on artist_top_tracks
    assert any('artist:"singer"' == c["q"] for c in cat.sp.calls)
    print("ok  artist_top: search-based (removed top-tracks endpoint avoided)")


def test_library_contains_new_shape():
    cat = Catalog(FakeSP())
    seen = {}

    def fake_get(url, headers=None, params=None, timeout=None):
        seen["url"] = url
        seen["uris"] = (params or {}).get("uris", "")
        return _Resp(200, [True, False, True])

    with patch("requests.get", fake_get):
        flags = cat._library_contains(["spotify:track:a", "spotify:track:b",
                                       "spotify:track:c"])
    assert flags == [True, False, True]
    assert seen["url"].endswith("/v1/me/library/contains")
    assert seen["uris"] == "spotify:track:a,spotify:track:b,spotify:track:c"
    print("ok  library contains: GET /me/library/contains with uri list")


def test_library_modify_put():
    cat = Catalog(FakeSP())
    from termify.models import Track
    tr = Track(id="a", uri="spotify:track:a", name="x", artists="", album="",
               duration_ms=1)
    with patch("requests.request", return_value=_Resp(200)) as m:
        cat.set_liked(tr, True)
    assert m.called
    url = m.call_args.args[1] if len(m.call_args.args) > 1 else m.call_args.kwargs.get("url", "")
    assert "/v1/me/library" in str(m.call_args)
    assert tr.liked is True
    print("ok  set_liked: PUT /me/library (new consolidated endpoint)")


def test_create_playlist_uses_me_endpoint():
    cat = Catalog(FakeSP())
    seen = []

    def fake_request(method, url, body=None):
        seen.append((method, url))
        return _Resp(201, {"id": "newpl", "uri": "spotify:playlist:newpl",
                           "name": body["name"]})

    cat._request = fake_request
    with patch.object(Catalog, "me_name", lambda self: "tester"):
        pl = cat.create_playlist("test vibes")
    assert pl is not None and pl.id == "newpl"
    assert seen[0][1].endswith("/v1/me/playlists"), seen
    assert not any("/users/" in u for _m, u in seen), "should not hit removed endpoint"
    print("ok  create_playlist: POST /me/playlists (not removed /users/{id}/playlists)")


if __name__ == "__main__":
    test_search_paginates_within_cap()
    test_search_all_sections()
    test_artist_top_uses_search_not_removed_endpoint()
    test_library_contains_new_shape()
    test_library_modify_put()
    test_create_playlist_uses_me_endpoint()
    print("\nALL API-MIGRATION TESTS PASSED")
