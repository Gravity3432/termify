"""Transport-button footer, big playlist cards, smooth+correct wheel scroll,
and the tiny shortcut legend.

Run from the project root:  python tests/test_footer_cards.py
"""
import time
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from rich.console import Console

from termify import ui
from termify.app import App
from termify.demo_engine import DemoEngine
from termify.models import Playlist


def make_app() -> App:
    app = App(DemoEngine(), {"volume": 60, "theme": "aurora"}, demo=True)
    app.snap = app.engine.snapshot()
    app.boot_skip()
    return app


def text_of(panel, w=110, h=6):
    console = Console(record=True, width=w, height=h)
    console.print(panel)
    return console.export_text()


def test_transport_buttons_render_and_click():
    app = make_app()
    W, H = 120, 36
    app.render(W, H)
    btns = {z["action"]: z for z in app.zones if z["type"] == "btn"}
    assert set(btns) == {"toggle", "prev", "next", "repeat", "shuffle"}, btns
    # footer shows the song name + buttons (capture before any toast fires)
    screen = text_of(ui.render_footer(app, W, 2, H - 3), W, 6)
    for marker in ("Neon Horizon", "❚❚", "◄◄", "►►", "⇄", "↻"):
        assert marker in screen, marker
    assert len(ui.KEY_LEGEND) <= 68, len(ui.KEY_LEGEND)
    # pause button pauses the demo engine
    z = btns["toggle"]
    app.on_mouse(0, z["x"], z["y"], True)
    time.sleep(0.4)
    assert app.engine._playing is False
    app.on_mouse(0, z["x"], z["y"], True)
    time.sleep(0.4)
    assert app.engine._playing is True
    # repeat cycles
    z = btns["repeat"]
    app.on_mouse(0, z["x"], z["y"], True)
    time.sleep(0.4)
    assert app.engine.repeat == "context"
    print("ok  transport buttons: render, click, toggle/repeat, song title, "
          "tiny legend")


def test_playlist_cards_big():
    app = make_app()
    names = [f"Mix {i}" for i in range(14)]
    app.rows["playlists"] = [
        Playlist(id=str(i), uri=f"spotify:playlist:{i}", name=n,
                 owner="johnthemailboy", count=7)
        for i, n in enumerate(names)]
    app.view = "playlists"
    W, H = 110, 30
    app.render(W, H)
    zones = [z for z in app.zones if z["type"] == "select"
             and z["view"] == "playlists"]
    assert zones and all(z["h"] == 2 for z in zones), zones[:2]  # TALL rows
    # window math still in card units and selection reachable
    app.sel["playlists"] = 14
    app.render(W, H)
    zones2 = [z["index"] for z in app.zones if z["type"] == "select"
              and z["view"] == "playlists"]
    assert max(zones2) >= 13  # scrolled down so the bottom card shows
    # deterministic cover colors
    c1a, c1b = ui._thumb_colors("Mix 3")
    c2a, c2b = ui._thumb_colors("Mix 4")
    assert c1a == ui._thumb_colors("Mix 3")[0] and c1a != c2a
    print("ok  playlist cards: 2-line tall rows, scroll window, colored thumbs")


def test_wheel_is_smooth_and_not_inverted():
    app = make_app()
    app.rows["playlists"] = [
        Playlist(id=str(i), uri=f"spotify:playlist:{i}", name=f"p{i}",
                 owner="o", count=1)
        for i in range(15)
    ]
    app.view = "playlists"
    app.render(110, 30)
    app.sel["playlists"] = 5
    app.on_mouse(65, 50, 15, False)  # wheel DOWN -> selection goes DOWN by one
    assert app.sel["playlists"] == 6
    app.on_mouse(64, 50, 15, False)  # wheel UP -> back UP by one
    assert app.sel["playlists"] == 5
    # and over the volume bar the wheel nudges volume the right way, gently
    W, H = 120, 36
    app.view = "home"
    app.render(W, H)
    vz = next(z for z in app.zones if z["type"] == "volume")
    v0 = app.cfg["volume"]
    app.on_mouse(64, vz["x"], vz["y"], False)   # wheel up = louder
    time.sleep(0.3)
    assert app.cfg["volume"] == v0 + 3, (v0, app.cfg["volume"])
    app.on_mouse(65, vz["x"], vz["y"], False)   # wheel down = quieter
    time.sleep(0.3)
    assert app.cfg["volume"] == v0
    print("ok  wheel: correct direction, smooth single steps, volume nudges")


if __name__ == "__main__":
    test_transport_buttons_render_and_click()
    test_playlist_cards_big()
    test_wheel_is_smooth_and_not_inverted()
    print("\nALL FOOTER/CARD TESTS PASSED")
