"""Tests for the feature drop: live FFT visualizer, lyrics, library view,
playlist editing, sleep timer, session resume.

Run from the project root:  python tests/test_features.py
"""
import math
import time
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from termify.audio_sink import FFTAnalyzer, SAMPLE_RATE
from termify.lyrics import _parse_lrc, current_index
from termify.app import App
from termify.demo_engine import DemoEngine, PLAYLISTS, BY_ID
from termify.models import Playlist


def make_app() -> App:
    app = App(DemoEngine(), {"volume": 60, "theme": "aurora"}, demo=True)
    app.snap = app.engine.snapshot()  # give it a "playing" snapshot
    app.boot_skip()                   # these tests drive keys: skip the splash
    return app


def test_fft_analyzer():
    an = FFTAnalyzer(n_bands=16)
    # silence -> silence
    an.push(b"\x00" * (an.window * 4))
    assert max(an.bands()) < 0.01
    # 300 Hz sine wave (stereo s16) -> energy in low-mid bands
    n = an.window
    frames = bytearray()
    for i in range(n):
        v = int(12000 * math.sin(2 * math.pi * 300 * i / SAMPLE_RATE))
        frames += v.to_bytes(2, "little", signed=True) * 2  # L = R
    an2 = FFTAnalyzer(n_bands=16)
    an2.push(bytes(frames))
    lv = an2.bands()
    assert len(lv) == 16 and max(lv) > 0.15, lv
    hot = lv.index(max(lv))
    assert hot < 8, f"300 Hz should light up the bass-ish bands, got band {hot}"
    print("ok  FFT analyzer: silence is quiet, sine lights the right bands")


def test_lyrics_parse_and_index():
    lrc = "[00:01.00]hello\n[00:05.50]world\n[01:10.00]later line\nnot-a-tag"
    synced = _parse_lrc(lrc)
    assert synced == [(1000, "hello"), (5500, "world"), (70000, "later line")]
    assert current_index(synced, 0) == 0
    assert current_index(synced, 4999) == 0
    assert current_index(synced, 5500) == 1
    assert current_index(synced, 99999) == 2
    print("ok  lyrics: LRC parsing + karaoke index math")


def test_lyrics_flow_demo():
    app = make_app()
    tr = app.snap.track
    app._tick_features()   # production entry point: stages id + queues fetch
    time.sleep(0.3)        # pool thread runs the (instant, offline) demo fetch
    st = app.lyrics_state
    assert st["id"] == tr.id and st["synced"] and st["loading"] is False
    # karaoke index tracks the demo clock
    idx = current_index(st["synced"], app.snap.position_ms)
    assert 0 <= idx < len(st["synced"])
    print("ok  lyrics: fetch + track-change state flow")


def test_library_rows():
    app = make_app()
    rows = app._fetch_library()
    sections = [o for k, o in rows if k == "section"]
    tracks = [o for k, o in rows if k == "track"]
    artists = [o for k, o in rows if k == "artist"]
    assert {"RECENTLY PLAYED", "YOUR TOP TRACKS · last 4 weeks",
            "YOUR TOP ARTISTS"} <= set(sections)
    assert tracks and artists
    # enter on an artist opens the artist view; nav digit 6 = devices, 5 = library
    app.view = "library"
    app.rows["library"] = rows
    app.dispatch("6")
    assert app.view == "devices"
    app.dispatch("5")
    assert app.view == "library"
    print("ok  library view: sections + tracks + artists + digit nav")


def test_playlist_editing_demo():
    eng = DemoEngine()
    n0 = len(PLAYLISTS)
    pl = eng.create_playlist("test vibes")
    assert pl and len(PLAYLISTS) == n0 + 1
    uri = BY_ID["demo02"].uri
    assert eng.add_to_playlist(pl.id, uri) is True
    assert "demo02" in PLAYLISTS[-1][2]
    assert eng.remove_from_playlist(pl.id, uri) is True
    assert "demo02" not in PLAYLISTS[-1][2]
    assert eng.add_to_playlist("demo_pl_9999", uri) is False
    print("ok  playlist editing: create / add / remove / reject-bad-id")


def test_picker_add_flow():
    app = make_app()
    app.rows["playlists"] = app.engine.get_playlists()
    # select a track in the liked list, press A, hit enter
    app.view = "liked"
    app.rows["liked"] = app.engine.get_liked()
    app.sel["liked"] = 0
    app._open_picker()
    assert app.picker is not None
    target = PLAYLISTS[app.picker["sel"]]
    before = list(target[2])
    app.dispatch("\r")
    time.sleep(0.3)  # pool thread does the add
    assert app.picker is None
    assert len(target[2]) == len(before) + 1, (before, target[2])
    print("ok  picker: A -> enter adds the track to the chosen playlist")


def test_remove_from_open_playlist():
    app = make_app()
    pl = Playlist(id="demo_pl_0", uri="u", name=PLAYLISTS[0][0], owner="termify")
    app.current_pl = pl
    app.view = "playlist_tracks"
    app.rows["playlist_tracks"] = app.engine.get_playlist_tracks(pl)
    victim = app.rows["playlist_tracks"][0]
    assert victim.uri.split(":")[-1] in PLAYLISTS[0][2]
    app.sel["playlist_tracks"] = 0
    app.dispatch("d")
    time.sleep(0.3)
    assert victim.uri.split(":")[-1] not in PLAYLISTS[0][2]
    print("ok  remove: 'd' pulls the track out of the open playlist")


def test_create_playlist_typing_flow():
    app = make_app()
    n0 = len(PLAYLISTS)
    app.dispatch("C")
    assert app.typing and app.typing_target == "playlist"
    for ch in "rainy day":
        app.dispatch(ch)
    app.dispatch("\r")
    time.sleep(0.3)
    assert len(PLAYLISTS) == n0 + 1
    assert PLAYLISTS[-1][0] == "rainy day"
    print("ok  create: C -> type name -> enter makes the playlist")


def test_sleep_timer():
    app = make_app()
    app.dispatch("Z")
    assert app.sleep_end is not None
    left = app.sleep_end - time.monotonic()
    assert 14 * 60 < left <= 15 * 60 + 1
    app.dispatch("Z")  # -> 30 min
    left = app.sleep_end - time.monotonic()
    assert 29 * 60 < left <= 30 * 60 + 1
    print("ok  sleep timer cycles 15 -> 30 min")


def test_resume():
    eng = DemoEngine()
    target = BY_ID["demo04"]
    eng.play_resume(target.uri, target.name, 61_000)
    snap = eng.snapshot()
    assert snap.track.id == "demo04"
    assert abs(snap.position_ms - 61_000) < 2000, snap.position_ms

    app = make_app()
    app._resume_offer = {"uri": target.uri, "name": target.name, "pos_ms": 5000}
    app._resume_last()
    time.sleep(0.3)
    assert app._resume_offer is None
    print("ok  resume: starts the saved track at the saved position")


def test_seek_30s_keys():
    app = make_app()
    before = app.snap.position_ms
    app.dispatch(".")  # +30s
    time.sleep(0.3)
    after = app.engine.snapshot().position_ms
    assert after - before > 25_000, (before, after)
    print("ok  ,/. jump 30 seconds")


def test_demo_bands():
    eng = DemoEngine()
    bands = eng.get_bands()
    assert len(bands) == 32 and all(0 <= b <= 1 for b in bands)
    print("ok  demo bands: 32 lively levels for the visualizer")


if __name__ == "__main__":
    test_fft_analyzer()
    test_lyrics_parse_and_index()
    test_lyrics_flow_demo()
    test_library_rows()
    test_playlist_editing_demo()
    test_picker_add_flow()
    test_remove_from_open_playlist()
    test_create_playlist_typing_flow()
    test_sleep_timer()
    test_resume()
    test_seek_30s_keys()
    test_demo_bands()
    print("\nALL FEATURE TESTS PASSED")
