"""Regression test: arrow keys on Windows.

Bug: input_layer normalizes every platform to VT-style sequences ("\x1b[A")
but app.py compared against readchar.key constants, which on Windows are
"\x00H"-style scan codes -> all special keys were dead on Windows.

This simulates "a Windows user pressed the Up arrow" through EVERY read
path and asserts the app actually reacts.

Run from the project root:  python tests/test_windows_keys.py
"""
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from termify import input_layer as il
from termify.app import App
from termify.demo_engine import DemoEngine
from termify.models import Playlist

# every form every supported platform/console may produce for special keys
WIN_FORMS = {
    "\x00H": il.K_UP, "\xe0H": il.K_UP,
    "\x00P": il.K_DOWN, "\xe0P": il.K_DOWN,
    "\x00M": il.K_RIGHT, "\xe0M": il.K_RIGHT,
    "\x00K": il.K_LEFT, "\xe0K": il.K_LEFT,
    "\x00I": il.K_PGUP, "\xe0I": il.K_PGUP,
    "\x00Q": il.K_PGDN, "\xe0Q": il.K_PGDN,
    "\x00G": il.K_HOME, "\xe0G": il.K_HOME,
    "\x00O": il.K_END, "\xe0O": il.K_END,
}


def make_app() -> App:
    app = App(DemoEngine(), {"volume": 60, "theme": "aurora"}, demo=True)
    app.boot_skip()  # these tests drive keys: skip the splash
    app.view = "playlists"
    app.rows["playlists"] = [
        Playlist(id=str(i), uri=f"spotify:playlist:{i}", name=f"pl {i}", owner="x", count=3)
        for i in range(15)
    ]
    return app


def test_normalize_key():
    for raw, canon in WIN_FORMS.items():
        assert il.normalize_key(raw) == canon, (raw, canon)
    print("ok  normalize_key maps every Windows scan-code form")


def test_fallback_readchar_path():
    """Fallback mode (readchar on Windows returns \x00H): must normalize."""
    import readchar

    r = il.InputReader()
    r._mode = "fallback"
    orig = readchar.readkey
    try:
        for raw, canon in WIN_FORMS.items():
            readchar.readkey = lambda raw=raw: raw
            assert r.read_event() == ("key", canon), raw
    finally:
        readchar.readkey = orig
    print("ok  fallback/readchar path normalizes Windows forms")


class _FakeMsvcrt:
    """Pretends to be the msvcrt module against a scripted key buffer."""

    def __init__(self, chars):
        self.buf = list(chars)

    def getwch(self):
        if not self.buf:
            raise AssertionError("script exhausted")
        return self.buf.pop(0)

    def kbhit(self):
        return bool(self.buf)


def test_windows_console_path():
    # 1) scan-code style: "\xe0" + "H" (legacy conhost / no VT input)
    r = il.InputReader()
    r._mode = "windows-msvcrt"
    r._msvcrt = _FakeMsvcrt(["\xe0", "H"])
    assert r.read_event() == ("key", il.K_UP)
    r._msvcrt = _FakeMsvcrt(["\x00", "P"])
    assert r.read_event() == ("key", il.K_DOWN)
    # 2) VT style: "\x1b[A" byte-by-byte (Windows Terminal w/ VT input on)
    r._msvcrt = _FakeMsvcrt(["\x1b", "[", "A"])
    assert r.read_event() == ("key", il.K_UP)
    print("ok  windows console path maps both scan-code and VT styles")


def test_dispatch_up_down_pg():
    app = make_app()
    assert app.sel["playlists"] == 0
    app.dispatch(il.K_DOWN)
    assert app.sel["playlists"] == 1
    app.dispatch(il.K_DOWN)
    app.dispatch(il.K_UP)
    assert app.sel["playlists"] == 1
    app.dispatch(il.K_PGDN)
    assert app.sel["playlists"] == 11
    app.dispatch(il.K_PGUP)
    assert app.sel["playlists"] == 1
    app.dispatch("G")
    # playlists view adds a pinned "liked songs" row: 15 playlists -> 16 rows
    assert app.sel["playlists"] == 15
    app.dispatch("g")
    assert app.sel["playlists"] == 0
    print("ok  dispatch moves selection with canonical key codes")


def test_full_windows_journey():
    """The exact regression: Windows up-arrow event -> selection moves."""
    app = make_app()
    app.sel["playlists"] = 5
    for read_path in ("scan", "vt", "readchar"):
        if read_path == "scan":
            r = il.InputReader()
            r._mode = "windows-msvcrt"
            r._msvcrt = _FakeMsvcrt(["\xe0", "H"])
            ev = r.read_event()
        elif read_path == "vt":
            r = il.InputReader()
            r._mode = "windows-msvcrt"
            r._msvcrt = _FakeMsvcrt(["\x1b", "[", "A"])
            ev = r.read_event()
        else:
            import readchar

            r = il.InputReader()
            r._mode = "fallback"
            orig = readchar.readkey
            readchar.readkey = lambda: "\x00H"
            try:
                ev = r.read_event()
            finally:
                readchar.readkey = orig
        kind, ch = ev
        assert kind == "key" and ch == il.K_UP, (read_path, ev)
        before = app.sel["playlists"]
        app.dispatch(ch)
        assert app.sel["playlists"] == before - 1, read_path
    print("ok  FULL journey: win up-arrow -> canonical -> selection moves (x3 paths)")


def test_typing_and_misc_keys():
    app = make_app()
    app.dispatch("/")
    assert app.typing is True
    for c in "lofi":
        app.dispatch(c)
    assert app.type_buf == "lofi"
    app.dispatch("\x08")
    assert app.type_buf == "lof"
    app.dispatch("\x7f")
    assert app.type_buf == "lo"
    app.dispatch(il.K_ESC)
    assert app.typing is False
    app.dispatch("?")
    assert app.help_visible is True
    app.dispatch(il.K_ESC)  # help eats one key
    assert app.help_visible is False
    app.dispatch("3")
    assert app.view == "playlists"
    print("ok  typing / backspace / esc / help / view digits all work")


if __name__ == "__main__":
    test_normalize_key()
    test_fallback_readchar_path()
    test_windows_console_path()
    test_dispatch_up_down_pg()
    test_full_windows_journey()
    test_typing_and_misc_keys()
    print("\nALL WINDOWS KEY TESTS PASSED")
