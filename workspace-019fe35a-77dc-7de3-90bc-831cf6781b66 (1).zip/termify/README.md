# ♪ Termify

**Spotify, minus the app.** A terminal client that *plays music itself* — no
Electron, no 800 MB of RAM, just a keyboard, color, and ASCII.
Made with ♥ by **@johnthemailboy**.

![Termify screenshot](docs/screenshot.png)

---

## What it does

- **Plays audio directly in the terminal** — Termify embeds an open-source
  Spotify Connect client (librespot), downloads and decrypts the audio stream,
  decodes it, and sends it to your speakers. The official desktop app is not
  needed at all.
- **Full playback control** — play/pause, next/prev, seek, volume, shuffle,
  repeat (off → all → one). The footer has real **transport buttons**
  (pause/prev/next/repeat/shuffle) you can click, plus a live song marquee
  and the volume bar.
- **Spotify-style search** — one query returns sections of **artists, albums,
  playlists and tracks**; drill into an artist's top tracks or an album's
  track list, then play anything with `enter`.
- **Sort your lists** — cycle default → title → artist → album → duration with `o`.
- **Your library** — all your playlists and Liked Songs, shown as big cards
  with colored cover-thumbs, browsable and playable.
- **Live audio visualizer** — the spectrum bars are driven by a real FFT of the
  music you're hearing (embedded-audio mode), not a clock.
- **Karaoke lyrics** — press `L` for a lyrics panel that follows the song line
  by line (synced via lrclib.net), and the Devices view (`6`) always shows a
  mini karaoke strip under your connected boxes. If lrclib comes up empty,
  Termify falls back to plain lyrics from **genius.com** and says so.
- **Library · Stats** — recently played plus your top tracks & top artists.
- **Edit playlists in-app** — `C` creates one, `A` adds the track under the
  cursor (or just **right-click any track**), `d` removes one from the
  playlist you're looking at.
- **Sleep timer** — `Z` cycles 15→30→45→60 min; Termify pauses for you.
- **Session resume** — remembers your track and position when you quit, offers
  `R` to pick up right where you left off.
- **Mouse support** — click/drag the **seek bar** to scrub to any spot in the
  song, click/drag the **volume bar**, click rows & the nav sidebar
  (double-click to play/open), click the alert-footer transport buttons, and
  the wheel glides one row at a time in the right direction. Keyboard still
  does everything, of course.
- **Queue view** — press `u` (or `7`) for the full up-next screen: now playing
  plus the whole line of songs waiting their turn, up to 100 deep. `enter`
  jumps straight to any of them, `d` kicks a song out of the queue
  (remove needs the embedded-audio mode; Spotify's API can't do it remotely),
  and the home screen shows a mini up-next strip too.
- **Like songs** with one key.
- **Instant-ish playback** — the music starts streaming after the *first
  128 KB* of the song (no waiting for a full download), and the next track
  in line secretly downloads while the current one plays, so skipping ahead
  feels immediate. A tiny buffer (`prebuffer_ms`, default 250 ms) stays
  because audio without any cushion would stutter - that's physics, not
  a bug. 🎧
- **Eye candy** — animated color-shifting gradients, ASCII album art rendered
  in truecolor half-blocks, an FFT spectrum visualizer, marquee track titles,
  and 6 swappable themes (`aurora`, `sunset`, `ocean`, `candy`, `vampire` 🦇
  with the dripping-blood banner, `mono`).
- **Boot intro** — every launch opens with the **JTMB** (John The Mail Boy)
  animation: neon rain, letters glitching into focus, tagline typing itself
  (and a blood-letters variant under the vampire theme). Any key skips it.
- **Demo mode** — see the whole UI with fake music before connecting anything:
  `python -m termify --demo`

> ⚠️ **Spotify Premium is required.** That's Spotify's rule for any
> third-party playback (server-side enforced), not a Termify limitation.

---

## Install

Needs **Python 3.10+**.

```bash
cd termify

# easiest: the launcher makes a venv + installs everything, then runs
./run.sh            # Linux / macOS
run.bat             # Windows (double-click or run in a terminal)

# or manually:
python -m venv .venv && source .venv/bin/activate   # .venv\Scripts\activate on Windows
pip install -r requirements.txt
python -m termify --demo        # try the offline demo first!
python -m termify               # the real thing
```

**Linux only:** audio output needs PortAudio —
`sudo apt install libportaudio2` (Debian/Ubuntu),
`sudo dnf install portaudio` (Fedora),
`sudo pacman -S portaudio` (Arch).
*macOS and Windows work out of the box.* If no audio backend can be found,
Termify falls back to piping sound to `ffplay`/`sox`/`paplay`/`aplay` if you
have one of those installed.

---

## First-run setup (~2 minutes, one time)

Termify talks to Spotify via an official **Spotify Developer** app (free):

1. Go to <https://developer.spotify.com/dashboard> and log in.
2. **Create app** → name it anything (e.g. `termify`).
3. Set the **Redirect URI** to exactly:

   ```
   http://127.0.0.1:4615/callback
   ```

   (you can leave “Which API/SDKs” at *Web API*), then **Save**.
4. Open the app's **Settings** and copy the **Client ID**.

Now run `python -m termify`. It asks for the Client ID, then:

1. **Login #1 (library):** a browser tab opens on `accounts.spotify.com` —
   approve it. This lets Termify read/manage your playlists & liked songs.
2. **Login #2 (audio):** it asks if you want in-terminal audio — say yes —
   and a second browser approval runs so Spotify trusts Termify as a
   *playback device*. (Only needed once.)

Tokens are stored encrypted/cached in `~/.termify/` — you'll never log in
again unless you delete them.

---

## Controls

| Keys | Action |
|---|---|
| `1`…`7` / `tab` | views: Home · Search · Playlists · Liked · **Library** · Devices · **Queue** |
| `↑ ↓` / `j k` | move selection |
| `enter` | play track / open artist / album / playlist / pick device / jump in queue |
| `u` | open the Queue view |
| `a` | play whole playlist from the top |
| `space` | play / pause |
| `n` / `b` | next / previous |
| `←` / `→` | seek ∓ 5 s · `,` / `.` seek ∓ 30 s |
| `+` / `−` | volume |
| `s` / `r` | shuffle · repeat (off → all → one) |
| `o` | sort list: default → title → artist → album → duration |
| `l` | like / unlike current track |
| `L` | karaoke lyrics panel |
| `A` | add track under cursor to a playlist |
| `C` | create a new playlist |
| `d` | remove track from the open playlist · kick a song out of the queue |
| `Z` | sleep timer: 15 → 30 → 45 → 60 min → off |
| `R` | resume last session |
| `/` | search everything (artists, albums, playlists, tracks) |
| `x` | reload current list |
| `m` | device picker |
| `t` | cycle color theme |
| `?` | keyboard map |
| `q` | quit |

| Mouse | Action |
|---|---|
| **click/drag seek bar** | jump to that time in the song |
| **click/drag volume bar** | set volume |
| **click a row** | select · **double-click** to play/open it |
| **click nav sidebar** | switch view |
| **scroll wheel** | scroll lists · over the volume bar, adjusts volume |

Mouse works best in **Windows Terminal** (free, Microsoft Store) or any modern
VT terminal — the legacy `cmd.exe` console may not deliver mouse events on old
Windows builds. Keyboard input works everywhere. If clicks seem to do nothing,
press `M` in the app: a live footer diagnostic shows the last mouse event and
whether your terminal is sending them at all.

---

## Two ways Termify can play

| Mode | How it works | When it's used |
|---|---|---|
| **Embedded audio** *(default)* | Termify itself streams, decodes and plays the track. Controls are local and instant. Fully replaces the desktop app. | After the one-time audio login, as long as an audio backend exists. |
| **Remote control** | Termify drives any Spotify device (phone, open.spotify.com tab, a speaker) over the Web API. | Automatic fallback if embedded audio isn't available, or with `--remote`. |

Force a mode: `python -m termify --remote` (or set `"mode": "remote"` in
`~/.termify/config.json`).

---

## Troubleshooting

- **A browser login pops up after an update** — new features sometimes need new
  Spotify permissions (e.g. creating playlists needs playlist-write access).
  Log in once and it stays saved.
- **Search shows "no results" for everything** — Spotify's Feb-2026 migration
  capped the search `limit` at 10 and older Termify builds asked for more, so
  Spotify rejected the whole call. Update to the latest files.
- **Artist pages say TRACKS instead of TOP TRACKS** — Spotify removed the
  artist top-tracks endpoint in Feb-2026; Termify now lists their tracks via
  an artist-scoped search instead.
- **Mouse clicks do nothing** — fixed in the latest files: on Windows,
  Termify now reads the console's native input records directly (keys *and*
  mouse), instead of interpreting escape sequences that some terminals eat.
  If clicks still misbehave, press `M` in-app for live mouse diagnostics
  (it shows the input mode and the last event received). Clicking works best
  in **Windows Terminal** (the default on Windows 11); the mouse line shows
  `on (windows)` when everything is wired up.
- **“decoder: Invalid data…” / some songs just don't play** — Spotify
  occasionally serves a stream whose *first bytes* are junk, and playback
  died right at the start. Termify (v0.1.1+) fights back in layers:
  1. every stream's first bytes are checked against the OGG magic before
     the decoder ever sees them — junk → instantly swapped for a fresh one;
  2. if decoding still fails, the song self-heals up to 3× (fresh live
     stream first, then a verified whole-file re-download, resuming mid-song
     from where you were — all silent, no error toast);
  3. prefetched next-songs are checked before they can poison the cache;
  4. if a song *still* refuses, it's auto-skipped like every other player
     does; only if everything fails (usually Wi-Fi) does Termify stop and
     say *“playback keeps failing”*.
  You'll hear at most a beat of silence instead of an error. Press `M`
  in-app to confirm you're on v0.1.1 (the version shows in the footer).
- **“No active device”** (remote mode) — open the Spotify app or
  <https://open.spotify.com> once on any device, press `m`, pick it.
  <https://open.spotify.com> once on any device, press `m`, pick it.
- **“a Premium account is required”** — playback endpoints are Premium-only.
- **No sound on Linux** → `sudo apt install libportaudio2` (see Install).
- **Port 4615 or 5588 already in use** → close whatever's using it and rerun;
  they're only needed during the one-time browser logins.
- **Weird colors / glyphs** → use a modern terminal (Windows Terminal,
  iTerm2, kitty, alacritty…) with a Nerd Font or DejaVu for the ♥▀█ glyphs.
- **`run.bat` flashes open and closes** → it hit an error and the window died
  with it. The updated `run.bat` pauses on failure; if you're on the old one,
  open a terminal in the folder instead (right-click the folder → *Open in
  Terminal*) and run `run.bat` there — you'll see the real error. Most common
  cause: Python isn't installed or wasn't added to PATH.
- **"`... was unexpected at this time`"** → that's cmd.exe failing to *parse*
  `run.bat`, usually because the file was re-saved with Unix (LF) line endings
  (copy-pasting the script into an editor does this). Fix: use the actual
  downloaded `run.bat` file (it ships with Windows CRLF endings), or skip the
  script entirely and run the three manual commands shown in Install.
- **Stale state / want a fresh start** → delete `~/.termify/`.
- To redo the client-id step: `python -m termify --setup`.

## Config & files

```
~/.termify/
├── config.json                 client_id, theme, volume, quality, device name
├── spotipy_token_cache         web-api token (auto-refreshing)
├── librespot_credentials.json  playback credential (never your password)
└── art_cache/                  downloaded album covers
```

Quality of the audio stream: `"quality": "normal" | "high" | "very_high"`
(ogg 96 / 160 / 320 kbps) in `config.json`.

Speed knobs: `"prebuffer_ms": 250` is the tiny cushion of decoded audio that
must exist before the first beat plays. You can lower it (music starts a
blink sooner) or raise it (more jitter-proof). Next-track prefetch happens
automatically — always.

## Roadmap ideas

Gapless crossfade, podcast/show browsing, follow/unfollow, an in-app
settings screen, sharing the whole thing on GitHub.

---

**Disclaimer:** unofficial, personal-use project; not affiliated with or
endorsed by Spotify AB. Spotify® is a trademark of Spotify AB. Use it within
Spotify's Terms of Service — it only ever streams to *your own* Premium
account. ♪
