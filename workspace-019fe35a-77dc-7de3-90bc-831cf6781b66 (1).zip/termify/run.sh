#!/bin/sh
# Termify launcher - creates a venv on first run, then starts the app.
cd "$(dirname "$0")" || exit 1

if [ ! -d .venv ]; then
  echo "first run: creating virtual environment…"
  python3 -m venv .venv || { echo "need python 3.10+ (python3-venv too)"; exit 1; }
  ./.venv/bin/pip install --quiet --upgrade pip
  ./.venv/bin/pip install --quiet -r requirements.txt
fi

exec ./.venv/bin/python -m termify "$@"
