@echo off
REM ==================================================
REM   JSKW INTRO - PREVIEW (no Flipper needed)
REM   by @johnthemailboy
REM   Keep this file NEXT TO JSKW_Intro.ps1, then
REM   double-click. Maximized window = best view.
REM   Press Q or Esc to quit.
REM ==================================================
start "" /max powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0JSKW_Intro.ps1"
