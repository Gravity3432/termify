# ==============================================================
#   J S K W   I N T R O
#   Game-Boy style boot-intro ... but it's YOU.
#   ASCII plasma + rainbow shooting stars + shimmer logo.
#   by @johnthemailboy
#
#   Works on Windows 10/11 (best in Windows Terminal).
#   Quit: Q or Esc
# ==============================================================

$ErrorActionPreference = 'SilentlyContinue'

# --- enable 24-bit ANSI colors --------------------------------
Add-Type -Name C -Namespace Jsi -MemberDefinition @'
[System.Runtime.InteropServices.DllImport("kernel32.dll")] public static extern System.IntPtr GetStdHandle(int n);
[System.Runtime.InteropServices.DllImport("kernel32.dll")] public static extern bool GetConsoleMode(System.IntPtr h, out uint mode);
[System.Runtime.InteropServices.DllImport("kernel32.dll")] public static extern bool SetConsoleMode(System.IntPtr h, uint mode);
'@

$hOut = [Jsi.C]::GetStdHandle(-11)
$cmode = 0
[void][Jsi.C]::GetConsoleMode($hOut, [ref]$cmode)
[void][Jsi.C]::SetConsoleMode($hOut, ($cmode -bor 4))

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
try { [Console]::BufferWidth = [Console]::WindowWidth } catch {}

${E}   = [char]27
$out = [Console]::Out
$rng = New-Object System.Random

[Console]::Title = 'JSKW'
try { [Console]::CursorVisible = $false } catch {}
Clear-Host

# ---------------- sine lookup table (speed!) -------------------
$SNT = 1024
$sin = New-Object 'double[]' $SNT
for ($i = 0; $i -lt $SNT; $i++) { $sin[$i] = [Math]::Sin($i * 2 * [Math]::PI / $SNT) }

# ---------------- heat-map plasma palette ----------------------
$palStops = @(
    @(0, 0, 0),       # deep black
    @(25, 8, 95),     # dark indigo
    @(70, 0, 185),    # violet
    @(190, 15, 195),  # magenta
    @(255, 60, 35),   # hot red
    @(255, 160, 0),   # ember orange
    @(255, 240, 150)  # white-hot
)
$ramp = ' .:-=+*#%@'
$PN   = 32
$pal  = New-Object 'string[]' $PN
$pch  = New-Object 'string[]' $PN
for ($i = 0; $i -lt $PN; $i++) {
    $f  = $i / ($PN - 1) * ($palStops.Count - 1)
    $si = [Math]::Min([int]$f, $palStops.Count - 2)
    $u  = $f - $si
    $a  = $palStops[$si]; $b = $palStops[$si + 1]
    $r  = [int]($a[0] + ($b[0] - $a[0]) * $u)
    $g  = [int]($a[1] + ($b[1] - $a[1]) * $u)
    $bl = [int]($a[2] + ($b[2] - $a[2]) * $u)
    $pal[$i] = "${E}[38;2;${r};${g};${bl}m"
    $pch[$i] = [string]$ramp[[int]($i * ($ramp.Length - 1) / ($PN - 1))]
}

# ---------------- HSV -> RGB helper ----------------------------
function Get-Hsv {
    param([double]$h, [double]$s, [double]$v)
    $h = $h - [Math]::Floor($h)
    $i = [int]($h * 6) % 6
    $f = $h * 6 - [Math]::Floor($h * 6)
    $p = $v * (1 - $s)
    $q = $v * (1 - $s * $f)
    $u = $v * (1 - $s * (1 - $f))
    switch ($i) {
        0 { $r = $v; $g = $u; $b = $p }
        1 { $r = $q; $g = $v; $b = $p }
        2 { $r = $p; $g = $v; $b = $u }
        3 { $r = $p; $g = $q; $b = $v }
        4 { $r = $u; $g = $p; $b = $v }
        5 { $r = $v; $g = $p; $b = $q }
    }
    , @([int]($r * 255), [int]($g * 255), [int]($b * 255))
}

# ---------------- the logo: J S K W ----------------------------
$Jj = @('██████', '   ██ ', '   ██ ', '█  ██ ', ' ███  ')
$Ss = @(' █████', '█     ', ' ████ ', '     █', '█████ ')
$Kk = @('█   █ ', '█  █  ', '███   ', '█  █  ', '█   █ ')
$Ww = @('█     █', '█     █', '█  █  █', '█ █ █ █', '██   ██')
$rows5 = foreach ($r in 0..4) { $Jj[$r] + ' ' + $Ss[$r] + ' ' + $Kk[$r] + ' ' + $Ww[$r] }
$sub  = '@johnthemailboy'
$scr  = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789#$%&@*+'.ToCharArray()

# ---------------- layout (recalculated on resize) --------------
function Set-Layout {
    $script:W = [Console]::WindowWidth
    $script:H = [Console]::WindowHeight
    $script:dbl = ($script:W -ge 64)
    $grows = foreach ($row in $rows5) {
        if ($script:dbl) { ($row.ToCharArray() | ForEach-Object { "$_$_" }) -join '' } else { $row }
    }
    $script:gdisp = @()
    foreach ($gr in $grows) { $script:gdisp += $gr; if ($script:dbl) { $script:gdisp += $gr } }
    $script:bw = $script:gdisp[0].Length
    $script:bh = $script:gdisp.Count
    $script:x0 = [Math]::Max(0, [int](($script:W - $script:bw) / 2))
    $script:y0 = [Math]::Max(0, [int](($script:H - $script:bh) / 2) - 2)
}
Set-Layout

# ---------------- shooting stars -------------------------------
$st_n  = 6
$st_on = New-Object 'bool[]'   $st_n
$st_x  = New-Object 'double[]' $st_n
$st_y  = New-Object 'double[]' $st_n
$st_dx = New-Object 'double[]' $st_n
$st_dy = New-Object 'double[]' $st_n
$st_hu = New-Object 'double[]' $st_n
$trail = @('*', '+', '.', '''', ' ')

# ---------------- banner painter -------------------------------
function Draw-Banner {
    param($sb, [int]$frame, [bool]$scramble, [int]$shineX)
    for ($r = 0; $r -lt $script:bh; $r++) {
        $ry = $script:y0 + $r
        if ($ry -ge ($script:H - 1)) { continue }
        [void]$sb.Append("${E}[$($ry + 1);$($script:x0 + 1)H")
        $line = [string]$script:gdisp[$r]
        $skip = 0
        for ($c = 0; $c -lt $line.Length; $c++) {
            if ($line[$c] -eq ' ') { $skip++; continue }   # plasma shows through the holes
            if ($skip -gt 0) { [void]$sb.Append("${E}[${skip}C"); $skip = 0 }
            if ($scramble) {
                $ch  = [string]$scr[$rng.Next($scr.Length)]
                $rgb = Get-Hsv ($rng.NextDouble()) 1 1     # full rainbow chaos while letters fly
            } else {
                # shimmering blue -> purple band drifting across (the GBA thing)
                $hue = 0.58 + 0.25 * (0.5 + 0.5 * [Math]::Sin($c * 0.11 + $frame * 0.028))
                $rgb = Get-Hsv $hue 0.85 1
                if ($shineX -ge 0) {                        # white shine sweep
                    $dist = [Math]::Abs($c - $shineX)
                    if ($dist -lt 5) {
                        $k = (5 - $dist) / 5.0
                        $rgb = @(
                            [Math]::Min(255, [int]($rgb[0] + (255 - $rgb[0]) * $k))
                            [Math]::Min(255, [int]($rgb[1] + (255 - $rgb[1]) * $k))
                            [Math]::Min(255, [int]($rgb[2] + (255 - $rgb[2]) * $k))
                        )
                    }
                }
                $ch = [string]$line[$c]
            }
            [void]$sb.Append("${E}[38;2;$($rgb[0]);$($rgb[1]);$($rgb[2])m").Append($ch)
        }
    }
}

# ==============================================================
#   MAIN LOOP
# ==============================================================
$frame   = 0
$running = $true
try {
    while ($running) {
        $sw = [Diagnostics.Stopwatch]::StartNew()

        # resize check (go fullscreen whenever, we adapt)
        if (($frame % 30) -eq 0) {
            if ([Console]::WindowWidth -ne $W -or [Console]::WindowHeight -ne $H) {
                Set-Layout
                Clear-Host
            }
        }
        $W2 = [Math]::Max(1, [int]($W / 2))

        # plasma phase offsets + the slow "pattern melt" blend factor
        $t1 = ($frame * 7) % 1024; $t2 = ($frame * 11) % 1024
        $t3 = ($frame * 5) % 1024; $t4 = ($frame * 13) % 1024
        $t5 = ($frame * 9) % 1024; $t6 = ($frame * 4) % 1024
        $t7 = ($frame * 6) % 1024; $t8 = ($frame * 10) % 1024
        $bf = 0.5 + 0.5 * $sin[($frame * 2) % 1024]
        $ib = 1 - $bf
        $cxA = ($W2 / 2) + ($W2 / 2.6) * $sin[($frame) % 1024]
        $cyA = ($H / 2) + ($H / 2.8) * $sin[($frame + 300) % 1024]
        $cxB = ($W2 / 2) + ($W2 / 2.4) * $sin[($frame + 500) % 1024]
        $cyB = ($H / 2) + ($H / 2.6) * $sin[($frame + 700) % 1024]

        $sb = New-Object System.Text.StringBuilder(120000)

        # ---- 1) ASCII plasma (two blended wave fields) ----
        for ($y = 0; $y -lt ($H - 1); $y++) {
            [void]$sb.Append("${E}[$($y + 1);1H")
            for ($cx = 0; $cx -lt $W2; $cx++) {
                $dAx = $cx - $cxA; $dAy = $y - $cyA
                $d1 = 2 * [int][Math]::Sqrt($dAx * $dAx + $dAy * $dAy)
                $v1 = $sin[($cx * 3 + $t1) -band 1023] + $sin[($y * 4 + $t2) -band 1023] + $sin[(($cx + $y) * 2 + $t3) -band 1023] + $sin[($d1 + $t4) -band 1023]
                $dBx = $cx - $cxB; $dBy = $y - $cyB
                $d2 = 2 * [int][Math]::Sqrt($dBx * $dBx + $dBy * $dBy)
                $v2 = $sin[($cx * 5 + $t5) -band 1023] + $sin[($y * 3 + $t6) -band 1023] + $sin[(($cx - $y + 512) * 2 + $t7) -band 1023] + $sin[($d2 + $t8) -band 1023]
                $v  = ($v1 * $ib + $v2 * $bf) / 4
                $pi = [int](($v + 1) * 16)
                if ($pi -lt 0) { $pi = 0 } elseif ($pi -gt 31) { $pi = 31 }
                [void]$sb.Append($pal[$pi]).Append($pch[$pi]).Append($pch[$pi])
            }
        }

        # ---- 2) rainbow shooting stars ----
        for ($i = 0; $i -lt $st_n; $i++) {
            if (-not $st_on[$i]) {
                if ($rng.NextDouble() -lt 0.03) {
                    $st_on[$i] = $true
                    $st_x[$i]  = $rng.Next(0, [Math]::Max(1, $W - 8))
                    $st_y[$i]  = 0
                    $dir       = @(1, -1)[$rng.Next(0, 2)]
                    $st_dx[$i] = $dir * (0.6 + $rng.NextDouble() * 0.9)
                    $st_dy[$i] = 0.5 + $rng.NextDouble() * 0.5
                    $st_hu[$i] = $rng.NextDouble()
                }
                continue
            }
            $st_x[$i]  += $st_dx[$i]
            $st_y[$i]  += $st_dy[$i]
            $st_hu[$i] += 0.02
            if ($st_y[$i] -ge ($H - 1) -or $st_x[$i] -lt 0 -or $st_x[$i] -ge $W) { $st_on[$i] = $false; continue }
            for ($k = 0; $k -lt 5; $k++) {
                $px = [int]($st_x[$i] - $st_dx[$i] * $k * 1.5)
                $py = [int]($st_y[$i] - $st_dy[$i] * $k * 1.5)
                if ($px -lt 0 -or $px -ge $W -or $py -lt 0 -or $py -ge ($H - 1)) { continue }
                $rgb = Get-Hsv ($st_hu[$i] - $k * 0.05) 0.9 (1 - $k * 0.19)
                [void]$sb.Append("${E}[$($py + 1);$($px + 1)H").Append("${E}[38;2;$($rgb[0]);$($rgb[1]);$($rgb[2])m").Append($trail[$k])
            }
        }

        # ---- 3) the JSKW logo: scramble -> resolve -> shimmer ----
        $scramble = ($frame -lt 42)
        $sx  = -1
        $cyc = $frame % 150
        if (-not $scramble -and $cyc -lt 26) { $sx = [int](($cyc / 25.0) * ($bw + 10)) - 5 }
        Draw-Banner $sb $frame $scramble $sx

        # the *bling!* when the letters lock in (Game Boy style)
        if ($frame -eq 42) {
            try { [Console]::Beep(1568, 120); [Console]::Beep(2093, 340) } catch {}
        }

        # little white sparkle twinkles on the logo
        if (-not $scramble -and ($frame % 40) -eq 0) {
            $script:tw = @($script:x0 + $rng.Next(0, [Math]::Max(1, $bw)), $script:y0 + $rng.Next(0, [Math]::Max(1, $bh)), $frame + 5)
        }
        if ($script:tw -and $frame -lt $script:tw[2]) {
            $tx = $script:tw[0]; $ty = $script:tw[1]
            if ($ty -lt ($H - 1) -and $tx -lt $W) {
                [void]$sb.Append("${E}[$($ty + 1);$($tx + 1)H").Append("${E}[38;2;255;255;255m*")
            }
        }

        # ---- 4) subtitle, like the Nintendo line ----
        if ($frame -ge 10 -and ($y0 + $bh + 1) -lt ($H - 1)) {
            $subx = [Math]::Max(0, [int](($W - $sub.Length) / 2))
            [void]$sb.Append("${E}[$($y0 + $bh + 2);$($subx + 1)H").Append("${E}[38;2;235;70;210m$sub")
        }

        $out.Write($sb.ToString())
        $frame++

        if ([Console]::KeyAvailable) {
            $k = [Console]::ReadKey($true)
            if ($k.Key -eq [ConsoleKey]::Escape -or $k.KeyChar -eq 'q' -or $k.KeyChar -eq 'Q') { $running = $false }
        }
        $ms = [int]$sw.ElapsedMilliseconds
        if ($ms -lt 40) { Start-Sleep -Milliseconds (40 - $ms) }
    }
}
finally {
    try { [Console]::CursorVisible = $true } catch {}
    [Console]::ResetColor()
    Clear-Host
    Write-Host "  JSKW intro - by @johnthemailboy" -ForegroundColor Magenta
}
