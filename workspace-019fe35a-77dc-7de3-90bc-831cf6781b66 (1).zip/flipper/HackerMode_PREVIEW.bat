@echo off
REM ==================================================
REM   H4CK3R M0D3 - PREVIEW (no Flipper needed)
REM   by @johnthemailboy
REM   Double-click to see exactly what the payload does.
REM   Harmless. Close the window or Ctrl+C to stop.
REM ==================================================
setlocal EnableDelayedExpansion

color 0a
title ACCESS GRANTED
prompt $g
mode con: cols=110 lines=32
cls

echo [*] Initializing uplink .......... OK
timeout /t 1 /nobreak >nul
echo [*] Bypassing firewall ........ OK
timeout /t 1 /nobreak >nul
echo [*] Cracking the mainframe .... OK
timeout /t 1 /nobreak >nul
echo.
echo.
echo          A C C E S S   G R A N T E D
echo.
echo.
timeout /t 2 /nobreak >nul

REM same infinite matrix rain as the payload
for /l %%i in (1,0,2) do @echo !RANDOM! !RANDOM! !RANDOM! !RANDOM! !RANDOM! !RANDOM! !RANDOM! !RANDOM! !RANDOM! !RANDOM!
